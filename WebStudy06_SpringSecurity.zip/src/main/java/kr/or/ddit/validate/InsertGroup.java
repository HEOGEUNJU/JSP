package kr.or.ddit.validate;

import javax.validation.groups.Default;

/**
 *	Marker interface
 */
public interface InsertGroup extends Default{
	
}
