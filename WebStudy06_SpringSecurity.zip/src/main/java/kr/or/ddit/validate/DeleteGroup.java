package kr.or.ddit.validate;

public interface DeleteGroup {

}
