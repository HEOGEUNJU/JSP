package kr.or.ddit.designpattern.adapterpattern;

public interface Target {
	public void request();
	
	
}
